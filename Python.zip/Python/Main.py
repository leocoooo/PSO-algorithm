# -*- coding: utf-8 -*-
"""
Created on Fri Feb  9 12:56:12 2024

@author: leoco
"""

# Particle Swarm Optimization

import autograd.numpy as np
from autograd import grad
import Functions as f
from OptTestFunctions import Rastrigin, Sphere

function_choice = input("What function do you want to minimize? \nAvailable functions: \n-Rastrigin \n-Sphere \n")

if function_choice == "Rastrigin":
    Function = Rastrigin
elif function_choice == "Sphere":
    Function = Sphere
else:
    print("Function not recognized. Exiting the program.")
    exit()
    
N = int(input("Enter the dimension of the problem: "))
# Initialization phase


if N%2==0: # Size of the swarm
    S = int(100*(N/2))
else:
    S =int(100*((N+1)/2))

ub = 5.12  # Upper bound for the search space
min_position = -ub * np.ones(shape=(S, 1))
max_position = ub * np.ones(shape=(S, 1))

X = min_position + np.random.rand(S, N) * (2 * max_position)

Pb = np.copy(X)

V = np.empty((S, N))

# Define the global best Gb for the first stage
Gb_image = Function(X[0,],N)
Gb = np.copy(X[0,])


# Final loop with a stopping criterion based on a maximum number of iterations

nbr_iter_max = 500*N/2
nbr_iter = 1

while nbr_iter < nbr_iter_max:
    # parameters initialization
    w = 0.9 - nbr_iter * (0.9 - 0.4) / nbr_iter_max
    #c1 = 2
    #c2 = 2
    c1 = 2 - nbr_iter *(2 -0.1) / nbr_iter_max
    c2 = 0.1 + nbr_iter *(2 -0.1) / nbr_iter_max

    # Reinitialization of V, X, Pb, Gb
    V = f.update_V(w, c1, c2, X, V, Pb, Gb)
    X = f.update_X(X, V)
    X = f.Penalty(X, N, S, ub)
    Pb = f.update_Pb(X, Pb, S, Function, N)
    Gb = f.update_Gb(Gb, Pb, S, Function, N)

    nbr_iter += 1

# Results
y_Gb = Function(Gb,N)
gradient = grad(Function)
grad_result = gradient(Gb, N)

Gb=np.round(Gb,2)
y_Gb=np.round(y_Gb,2)
grad_result=np.round(grad_result,2)

print("The global solution is", Gb, "\nThe image is", y_Gb, "\nAnd the gradient is", grad_result)

