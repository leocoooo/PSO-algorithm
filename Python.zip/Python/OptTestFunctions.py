# -*- coding: utf-8 -*-
"""
Created on Sat Feb 10 12:38:59 2024

@author: leoco
"""

import autograd.numpy as np

# Defining an optimization test function
def Rastrigin(X,N):
    y = 10 * N + np.sum([(x**2 - 10 * np.cos(2 * np.pi * x)) for x in X])
    return y

#min = 0

def Sphere(X,N):
    y = np.sum((x - 1)**2 for x in X) - 4
    return y

#min= 1
